#Запуск системы
import boot
